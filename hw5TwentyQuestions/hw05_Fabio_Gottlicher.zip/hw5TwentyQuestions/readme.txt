Questions:								Question path:
1. Is it front engine car? 				("")
2. Is it rear wheel drive? 				("y")
3. Is it Italian?						("n")
4. Does it have a I6 engine? 			("yy")
5. Does it have a VR6 engine? 			("yn")
6. Does it have a horse in its logo? 	("ny")
7. Is it German? 						("nn")

8. Is it a BMW E36 328i? 				("yyy")
9. Is it a Nissan 240SX? 				("yyn")
10. Is it a VW Golf R32?				("yny")
11. Is it a Toyota Camry?				("ynn")
12. Is it a Ferrari Testarossa?			("nyy")
13. Is it a Lamborghini Murciélago?		("nyn")
14. Is it a Porsche 911 GT3?			("nny")
15. Is it a Honda NSX?					("nnn")

Anwers:
BMW E36 328i - yes on 1, yes on 2, yes on 4
Nissan 240SX - yes on 1, yes on 2, no on 4
VW Golf R32 - yes on 1, no on 2, yes on 5
Toyota Camry - yes on 1, no on 2, no on 5
Ferrari Testarossa - no on 1, yes on 3, yes on 6
Lamborghini Murciélago - no on 1, yes on 3, no on 6
Porsche 911 GT3 - no on 1, no on 3, yes on 7
Honda NSX - no on 1, no on 3, no on 7
-----------------------------------------------
KeyEventHandler: http://msdn.microsoft.com/en-us/library/system.windows.input.keyeventhandler(v=vs.110).aspx
Linq: http://msdn.microsoft.com/en-us/library/bb397926.aspx
internal: http://msdn.microsoft.com/en-us/library/7c5ka91b.aspx - used to denote classed/method that can't be accesed from other assemblies
