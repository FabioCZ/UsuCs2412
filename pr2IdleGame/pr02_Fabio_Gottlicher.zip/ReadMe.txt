This is a fun little clicker/idle/incremental game. The point of this game? Make numbers bigger!
You click to get resources, and to get upgrades to make clicking easier/automated.
You can buy workers to automatically generate resources, but they need a place to live.
You can also use key shortcuts:
a - get food
s - get wood
d - get stone
f - get gold

You can just play on forever till numbers get super big (Hopefully not so big that you run out of label space).

Two attached screenshots shows a basic game state and an error message when you don't enough resources for upgrades.


Fabio Gottlicher, A01647928, CS2412 Fa2014