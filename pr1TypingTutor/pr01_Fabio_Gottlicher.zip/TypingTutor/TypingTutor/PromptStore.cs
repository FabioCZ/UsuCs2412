﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypingTutor
{
    public static class PromptStore
    {
        public const String prompt1 = "A typed word is counted as any five keystrokes.";
        public const String prompt2 = "The beautiful scenic country of New Zealand is situated in the South Pacific to the east of Australia.";
        public const String prompt3 = "NZ's East Coast has many stretches of white sand and rolling surf which attract NZ and overseas surfers. They are popular NZ fmaily holiday places.";
        public const String prompt4 = "Masters' Games are very popular in New Zealand as in many other countries and NZ swimmers were really proud in the year 2002 to host the FINA World Masters Swimming Champs at Christchurch in the South Island, at which I gained 10th place medals for 100 m and 200 m backstroke.";
        public const String prompt5 = "New Zealand is a very sport oriented country and sometimes hosts world events. Sports include tennis, golf, yachting, canoeing, cruising, cricket, soccer, rugby, basketball, netball, swimming, surf lifesaving, athletics, and riding";
        public static String customPrompt = "not set";
    }
}
