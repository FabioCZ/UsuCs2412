﻿namespace TypingTutor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.groupBoxRadios = new System.Windows.Forms.GroupBox();
            this.radioButtonFile = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.labelErrorsText = new System.Windows.Forms.Label();
            this.typingBox = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadPromptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveResultsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.instructionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.labelPrompt = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBoxKeyboard = new System.Windows.Forms.GroupBox();
            this.labelAccuracyText = new System.Windows.Forms.Label();
            this.labelErrors = new System.Windows.Forms.Label();
            this.labelAccuracy = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.groupBoxRadios.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBoxKeyboard.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(30, 30);
            this.button1.TabIndex = 0;
            this.button1.Text = "`";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(186, 19);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(30, 30);
            this.button2.TabIndex = 1;
            this.button2.Text = "5";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(150, 19);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(30, 30);
            this.button3.TabIndex = 2;
            this.button3.Text = "4";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(114, 19);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(30, 30);
            this.button4.TabIndex = 3;
            this.button4.Text = "3";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(78, 19);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(30, 30);
            this.button5.TabIndex = 4;
            this.button5.Text = "2";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(42, 19);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(30, 30);
            this.button6.TabIndex = 5;
            this.button6.Text = "1";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(258, 19);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(30, 30);
            this.button7.TabIndex = 11;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(294, 19);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(30, 30);
            this.button8.TabIndex = 10;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(330, 19);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(30, 30);
            this.button9.TabIndex = 9;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(366, 19);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(30, 30);
            this.button10.TabIndex = 8;
            this.button10.Text = "0";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(402, 19);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(30, 30);
            this.button11.TabIndex = 7;
            this.button11.Text = "-";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(222, 19);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(30, 30);
            this.button12.TabIndex = 6;
            this.button12.Text = "6";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(438, 19);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(30, 30);
            this.button13.TabIndex = 12;
            this.button13.Text = "=";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(491, 55);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(30, 30);
            this.button14.TabIndex = 25;
            this.button14.Text = "\\";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(311, 55);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(30, 30);
            this.button15.TabIndex = 24;
            this.button15.Text = "I";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(347, 55);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(30, 30);
            this.button16.TabIndex = 23;
            this.button16.Text = "O";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(383, 55);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(30, 30);
            this.button17.TabIndex = 22;
            this.button17.Text = "P";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(419, 55);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(30, 30);
            this.button18.TabIndex = 21;
            this.button18.Text = "[";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(455, 55);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(30, 30);
            this.button19.TabIndex = 20;
            this.button19.Text = "]";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(275, 55);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(30, 30);
            this.button20.TabIndex = 19;
            this.button20.Text = "U";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(95, 55);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(30, 30);
            this.button21.TabIndex = 18;
            this.button21.Text = "W";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(131, 55);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(30, 30);
            this.button22.TabIndex = 17;
            this.button22.Text = "E";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(167, 55);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(30, 30);
            this.button23.TabIndex = 16;
            this.button23.Text = "R";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(203, 55);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(30, 30);
            this.button24.TabIndex = 15;
            this.button24.Text = "T";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(239, 55);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(30, 30);
            this.button25.TabIndex = 14;
            this.button25.Text = "Y";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(59, 55);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(30, 30);
            this.button26.TabIndex = 13;
            this.button26.Text = "Q";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(337, 127);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(30, 30);
            this.button28.TabIndex = 49;
            this.button28.Text = ",";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(373, 127);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(30, 30);
            this.button29.TabIndex = 48;
            this.button29.Text = ".";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(409, 127);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(30, 30);
            this.button30.TabIndex = 47;
            this.button30.Text = "/";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(301, 127);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(30, 30);
            this.button33.TabIndex = 44;
            this.button33.Text = "M";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(121, 127);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(30, 30);
            this.button34.TabIndex = 43;
            this.button34.Text = "X";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(157, 127);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(30, 30);
            this.button35.TabIndex = 42;
            this.button35.Text = "C";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(193, 127);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(30, 30);
            this.button36.TabIndex = 41;
            this.button36.Text = "V";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(229, 127);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(30, 30);
            this.button37.TabIndex = 40;
            this.button37.Text = "B";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(265, 127);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(30, 30);
            this.button38.TabIndex = 39;
            this.button38.Text = "N";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(85, 127);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(30, 30);
            this.button39.TabIndex = 38;
            this.button39.Text = "Z";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(284, 91);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(30, 30);
            this.button41.TabIndex = 36;
            this.button41.Text = "J";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(320, 91);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(30, 30);
            this.button42.TabIndex = 35;
            this.button42.Text = "K";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(356, 91);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(30, 30);
            this.button43.TabIndex = 34;
            this.button43.Text = "L";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(392, 91);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(30, 30);
            this.button44.TabIndex = 33;
            this.button44.Text = ";";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(428, 91);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(30, 30);
            this.button45.TabIndex = 32;
            this.button45.Text = "\'";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(248, 91);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(30, 30);
            this.button46.TabIndex = 31;
            this.button46.Text = "H";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(68, 91);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(30, 30);
            this.button47.TabIndex = 30;
            this.button47.Text = "A";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(104, 91);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(30, 30);
            this.button48.TabIndex = 29;
            this.button48.Text = "S";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(140, 91);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(30, 30);
            this.button49.TabIndex = 28;
            this.button49.Text = "D";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(176, 91);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(30, 30);
            this.button50.TabIndex = 27;
            this.button50.Text = "F";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(212, 91);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(30, 30);
            this.button51.TabIndex = 26;
            this.button51.Text = "G";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(6, 91);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(56, 30);
            this.button27.TabIndex = 50;
            this.button27.Text = "CAPS";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(6, 127);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(73, 30);
            this.button31.TabIndex = 51;
            this.button31.Text = "L SHIFT";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(445, 127);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(76, 30);
            this.button32.TabIndex = 52;
            this.button32.Text = "R SHIFT";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(464, 91);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(57, 30);
            this.button40.TabIndex = 53;
            this.button40.Text = "ENTER";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(474, 19);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(47, 30);
            this.button52.TabIndex = 54;
            this.button52.Text = "BKSP";
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(6, 55);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(47, 30);
            this.button53.TabIndex = 55;
            this.button53.Text = "TAB";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(157, 163);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(174, 30);
            this.button54.TabIndex = 56;
            this.button54.Text = "SPACE";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // groupBoxRadios
            // 
            this.groupBoxRadios.Controls.Add(this.radioButtonFile);
            this.groupBoxRadios.Controls.Add(this.radioButton5);
            this.groupBoxRadios.Controls.Add(this.radioButton4);
            this.groupBoxRadios.Controls.Add(this.radioButton3);
            this.groupBoxRadios.Controls.Add(this.radioButton2);
            this.groupBoxRadios.Controls.Add(this.radioButton1);
            this.groupBoxRadios.Location = new System.Drawing.Point(13, 30);
            this.groupBoxRadios.Name = "groupBoxRadios";
            this.groupBoxRadios.Size = new System.Drawing.Size(246, 74);
            this.groupBoxRadios.TabIndex = 58;
            this.groupBoxRadios.TabStop = false;
            this.groupBoxRadios.Text = "Prompt Selection";
            // 
            // radioButtonFile
            // 
            this.radioButtonFile.AutoSize = true;
            this.radioButtonFile.Enabled = false;
            this.radioButtonFile.Location = new System.Drawing.Point(144, 44);
            this.radioButtonFile.Name = "radioButtonFile";
            this.radioButtonFile.Size = new System.Drawing.Size(67, 17);
            this.radioButtonFile.TabIndex = 5;
            this.radioButtonFile.TabStop = true;
            this.radioButtonFile.Text = "From File";
            this.radioButtonFile.UseVisualStyleBackColor = true;
            this.radioButtonFile.CheckedChanged += new System.EventHandler(this.promptSelection_CheckedChanged);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(144, 20);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(64, 17);
            this.radioButton5.TabIndex = 4;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Prompt5";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.promptSelection_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(74, 44);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(64, 17);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Prompt4";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.promptSelection_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(74, 20);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(64, 17);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Prompt3";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.promptSelection_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(7, 44);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(64, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Prompt2";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.promptSelection_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(7, 20);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(64, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Prompt1";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.promptSelection_CheckedChanged);
            // 
            // labelErrorsText
            // 
            this.labelErrorsText.AutoSize = true;
            this.labelErrorsText.Location = new System.Drawing.Point(268, 39);
            this.labelErrorsText.Name = "labelErrorsText";
            this.labelErrorsText.Size = new System.Drawing.Size(88, 13);
            this.labelErrorsText.TabIndex = 59;
            this.labelErrorsText.Text = "Number of errors:";
            // 
            // typingBox
            // 
            this.typingBox.Location = new System.Drawing.Point(13, 197);
            this.typingBox.Name = "typingBox";
            this.typingBox.ShortcutsEnabled = false;
            this.typingBox.Size = new System.Drawing.Size(532, 80);
            this.typingBox.TabIndex = 60;
            this.typingBox.TabStop = false;
            this.typingBox.Text = "";
            this.typingBox.TextChanged += new System.EventHandler(this.typingBox_TextChanged);
            this.typingBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.typingBox_KeyDown);
            this.typingBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.typingBox_KeyUp);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(555, 24);
            this.menuStrip1.TabIndex = 61;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadPromptToolStripMenuItem,
            this.saveResultsToolStripMenuItem,
            this.exitToolStripMenuItem,
            this.exitToolStripMenuItem1});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadPromptToolStripMenuItem
            // 
            this.loadPromptToolStripMenuItem.Name = "loadPromptToolStripMenuItem";
            this.loadPromptToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.loadPromptToolStripMenuItem.Text = "Select Prompt File";
            this.loadPromptToolStripMenuItem.Click += new System.EventHandler(this.loadPromptToolStripMenuItem_Click);
            // 
            // saveResultsToolStripMenuItem
            // 
            this.saveResultsToolStripMenuItem.Enabled = false;
            this.saveResultsToolStripMenuItem.Name = "saveResultsToolStripMenuItem";
            this.saveResultsToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.saveResultsToolStripMenuItem.Text = "Save Results";
            this.saveResultsToolStripMenuItem.Click += new System.EventHandler(this.saveResultsToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.exitToolStripMenuItem.Text = "Reset";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(169, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.instructionsToolStripMenuItem,
            this.aboutToolStripMenuItem1});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.aboutToolStripMenuItem.Text = "Help";
            // 
            // instructionsToolStripMenuItem
            // 
            this.instructionsToolStripMenuItem.Name = "instructionsToolStripMenuItem";
            this.instructionsToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.instructionsToolStripMenuItem.Text = "Instructions";
            this.instructionsToolStripMenuItem.Click += new System.EventHandler(this.instructionsToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(136, 22);
            this.aboutToolStripMenuItem1.Text = "About";
            this.aboutToolStripMenuItem1.Click += new System.EventHandler(this.aboutToolStripMenuItem1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.labelPrompt);
            this.groupBox2.Location = new System.Drawing.Point(13, 111);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(532, 80);
            this.groupBox2.TabIndex = 62;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Prompt";
            // 
            // labelPrompt
            // 
            this.labelPrompt.Location = new System.Drawing.Point(7, 20);
            this.labelPrompt.Name = "labelPrompt";
            this.labelPrompt.Size = new System.Drawing.Size(519, 57);
            this.labelPrompt.TabIndex = 0;
            this.labelPrompt.Text = "Please select prompt";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Text files|*.txt";
            // 
            // groupBoxKeyboard
            // 
            this.groupBoxKeyboard.Controls.Add(this.button1);
            this.groupBoxKeyboard.Controls.Add(this.button2);
            this.groupBoxKeyboard.Controls.Add(this.button3);
            this.groupBoxKeyboard.Controls.Add(this.button4);
            this.groupBoxKeyboard.Controls.Add(this.button5);
            this.groupBoxKeyboard.Controls.Add(this.button54);
            this.groupBoxKeyboard.Controls.Add(this.button6);
            this.groupBoxKeyboard.Controls.Add(this.button53);
            this.groupBoxKeyboard.Controls.Add(this.button12);
            this.groupBoxKeyboard.Controls.Add(this.button52);
            this.groupBoxKeyboard.Controls.Add(this.button11);
            this.groupBoxKeyboard.Controls.Add(this.button40);
            this.groupBoxKeyboard.Controls.Add(this.button10);
            this.groupBoxKeyboard.Controls.Add(this.button32);
            this.groupBoxKeyboard.Controls.Add(this.button9);
            this.groupBoxKeyboard.Controls.Add(this.button31);
            this.groupBoxKeyboard.Controls.Add(this.button8);
            this.groupBoxKeyboard.Controls.Add(this.button27);
            this.groupBoxKeyboard.Controls.Add(this.button7);
            this.groupBoxKeyboard.Controls.Add(this.button28);
            this.groupBoxKeyboard.Controls.Add(this.button13);
            this.groupBoxKeyboard.Controls.Add(this.button29);
            this.groupBoxKeyboard.Controls.Add(this.button26);
            this.groupBoxKeyboard.Controls.Add(this.button30);
            this.groupBoxKeyboard.Controls.Add(this.button25);
            this.groupBoxKeyboard.Controls.Add(this.button33);
            this.groupBoxKeyboard.Controls.Add(this.button24);
            this.groupBoxKeyboard.Controls.Add(this.button34);
            this.groupBoxKeyboard.Controls.Add(this.button23);
            this.groupBoxKeyboard.Controls.Add(this.button35);
            this.groupBoxKeyboard.Controls.Add(this.button22);
            this.groupBoxKeyboard.Controls.Add(this.button36);
            this.groupBoxKeyboard.Controls.Add(this.button21);
            this.groupBoxKeyboard.Controls.Add(this.button37);
            this.groupBoxKeyboard.Controls.Add(this.button20);
            this.groupBoxKeyboard.Controls.Add(this.button38);
            this.groupBoxKeyboard.Controls.Add(this.button19);
            this.groupBoxKeyboard.Controls.Add(this.button39);
            this.groupBoxKeyboard.Controls.Add(this.button18);
            this.groupBoxKeyboard.Controls.Add(this.button41);
            this.groupBoxKeyboard.Controls.Add(this.button17);
            this.groupBoxKeyboard.Controls.Add(this.button42);
            this.groupBoxKeyboard.Controls.Add(this.button16);
            this.groupBoxKeyboard.Controls.Add(this.button43);
            this.groupBoxKeyboard.Controls.Add(this.button15);
            this.groupBoxKeyboard.Controls.Add(this.button44);
            this.groupBoxKeyboard.Controls.Add(this.button14);
            this.groupBoxKeyboard.Controls.Add(this.button45);
            this.groupBoxKeyboard.Controls.Add(this.button51);
            this.groupBoxKeyboard.Controls.Add(this.button46);
            this.groupBoxKeyboard.Controls.Add(this.button50);
            this.groupBoxKeyboard.Controls.Add(this.button47);
            this.groupBoxKeyboard.Controls.Add(this.button49);
            this.groupBoxKeyboard.Controls.Add(this.button48);
            this.groupBoxKeyboard.Location = new System.Drawing.Point(13, 283);
            this.groupBoxKeyboard.Name = "groupBoxKeyboard";
            this.groupBoxKeyboard.Size = new System.Drawing.Size(530, 206);
            this.groupBoxKeyboard.TabIndex = 63;
            this.groupBoxKeyboard.TabStop = false;
            this.groupBoxKeyboard.Text = "Keyboard";
            // 
            // labelAccuracyText
            // 
            this.labelAccuracyText.AutoSize = true;
            this.labelAccuracyText.Location = new System.Drawing.Point(268, 52);
            this.labelAccuracyText.Name = "labelAccuracyText";
            this.labelAccuracyText.Size = new System.Drawing.Size(55, 13);
            this.labelAccuracyText.TabIndex = 64;
            this.labelAccuracyText.Text = "Accuracy:";
            // 
            // labelErrors
            // 
            this.labelErrors.AutoSize = true;
            this.labelErrors.Location = new System.Drawing.Point(357, 39);
            this.labelErrors.Name = "labelErrors";
            this.labelErrors.Size = new System.Drawing.Size(13, 13);
            this.labelErrors.TabIndex = 65;
            this.labelErrors.Text = "0";
            // 
            // labelAccuracy
            // 
            this.labelAccuracy.AutoSize = true;
            this.labelAccuracy.Location = new System.Drawing.Point(357, 54);
            this.labelAccuracy.Name = "labelAccuracy";
            this.labelAccuracy.Size = new System.Drawing.Size(13, 13);
            this.labelAccuracy.TabIndex = 66;
            this.labelAccuracy.Text = "0";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Text files|*.txt";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 501);
            this.Controls.Add(this.labelAccuracy);
            this.Controls.Add(this.labelErrors);
            this.Controls.Add(this.labelAccuracyText);
            this.Controls.Add(this.groupBoxKeyboard);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.typingBox);
            this.Controls.Add(this.labelErrorsText);
            this.Controls.Add(this.groupBoxRadios);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Awesome Typing Tutor";
            this.groupBoxRadios.ResumeLayout(false);
            this.groupBoxRadios.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBoxKeyboard.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.GroupBox groupBoxRadios;
        private System.Windows.Forms.Label labelErrorsText;
        private System.Windows.Forms.RichTextBox typingBox;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadPromptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem instructionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
        private System.Windows.Forms.RadioButton radioButtonFile;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label labelPrompt;
        private System.Windows.Forms.GroupBox groupBoxKeyboard;
        private System.Windows.Forms.Label labelAccuracyText;
        private System.Windows.Forms.Label labelErrors;
        private System.Windows.Forms.Label labelAccuracy;
        private System.Windows.Forms.ToolStripMenuItem saveResultsToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}

